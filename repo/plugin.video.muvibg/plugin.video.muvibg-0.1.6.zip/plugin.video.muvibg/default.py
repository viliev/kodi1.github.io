# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urlresolver
import feedparser
from datetime import datetime

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.muvibg'
__Addon = xbmcaddon.Addon(__addon_id__)
searchicon = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/search.png")
__settings__ = xbmcaddon.Addon(id='plugin.video.muvibg')
source =__settings__.getSetting('source')
if source =='0':
    #print 'MUVIBG'
    site='http://muvibg.com/'
elif source =='1':
    #print 'FILMISUB'
    site='http://filmisub.com/'
    logo='http://filmisub.com/templates/filmisub/images/logo.png'
elif source =='2':
    #print 'FILMI7'
    site='http://filmi7.com/'
    logo='http://filmi7.com/templates/filmi7/images/logo.png'
else:
    #print 'FILMISUB'
    site='http://filmisub.com/'
    logo='http://filmisub.com/templates/filmisub/images/logo.png'

MUA = 'Mozilla/5.0 (Linux; Android 5.0.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19' #За симулиране на заявка от мобилно устройство
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0' #За симулиране на заявка от  компютърен браузър

headers={
                    'GET' : '/video/t/hNT5ac2tkPXzvReA746oQ49XJFHNHhVd/15360/ HTTP/1.1',
                    'Host' : 'hdgo.cc',
                    'Accept-Language' : 'bg,en-US;q=0.8,en;q=0.6',
                    'User-Agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/43.0.2357.130 Chrome/43.0.2357.130 Safari/537.36',
                    'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Accept' : '*/*',
                    'Referer' : 'http://hdgo.cc/',
                    'X-Requested-With' : 'XMLHttpRequest',
                    'Connection' : 'keep-alive',
                    'DNT' : '1'
                }

#Меню с директории в приставката
def CATEGORIES():
        addDir('Търсене',site+'xfsearch/',2,searchicon)
        addDir('Очаквайте скоро...',site+'trailers/page/1',1,'')
        if source =='0':
            addDir('Последно добавени',site+'rss.xml',5,'')
        else:
            addDir('Последно добавени',site+'filmi/page/1',1,'')
        if (source =='1' or source =='2'):
            addDir('Филми с обновени линкове',site+'last-edited.html',1,'')
        addDir('Филми по години','years',6,'')
        addDir('ТОП 100 филми','http://filmisub.com/top100-filmi.html',1,'')
        addDir('ТОП 100 сериали','http://filmisub.com/top100-seriali.html',1,'')
        addDir('Руски сериали',site+'tags/%D1%80%D1%83%D1%81%D0%BA%D0%B8+%D1%81%D0%B5%D1%80%D0%B8%D0%B0%D0%BB%D0%B8/page/1',1,'')
        addDir('Испански сериали',site+'tags/%D0%B8%D1%81%D0%BF%D0%B0%D0%BD%D1%81%D0%BA%D0%B8+%D1%81%D0%B5%D1%80%D0%B8%D0%B0%D0%BB%D0%B8/page/1',1,'')
        addDir('Сериали с нови епизоди','http://filmisub.com/last-edited-seriali.html',1,'')
        addDir('Сериали',site+'seriali/page/1',1,'')
        addDir('БГ Аудио',site+'bgaudio/page/1',1,'')
        addDir('Екшън',site+'ekshani/page/1',1,'')
        addDir('Комедия',site+'komedii/page/1',1,'')
        addDir('Трилър',site+'trilari/page/1',1,'')
        addDir('Ужаси',site+'ujasi/page/1',1,'')
        addDir('Криминален',site+'kriminalni/page/1',1,'')
        addDir('Фантастика',site+'fantastika/page/1',1,'')
        addDir('Драма',site+'drami/page/1',1,'')
        addDir('Романтичен',site+'romantichni/page/1',1,'')
        addDir('Приключенски',site+'prikluchenski/page/1',1,'')
        addDir('Анимация',site+'animacii/page/1',1,'')
        addDir('Исторически',site+'istoricheski/page/1',1,'')
        addDir('Мистерия',site+'misterii/page/1',1,'')
        addDir('Фентъзи',site+'fentazi/page/1',1,'')
        addDir('Военен',site+'voenni/page/1',1,'')
        addDir('Семеен',site+'semeini/page/1',1,'')
        addDir('Уестърн',site+'western/page/1',1,'')
        addDir('Документален',site+'dokumentalni/page/1',1,'')
        addDir('Европейски',site+'xfsearch/%D0%95%D0%B2%D1%80%D0%BE%D0%BF%D0%B5%D0%B9%D1%81%D0%BA%D0%B8/page/1',1,'')
        addDir('Скандинавски',site+'xfsearch/%D0%A1%D0%BA%D0%B0%D0%BD%D0%B4%D0%B8%D0%BD%D0%B0%D0%B2%D1%81%D0%BA%D0%B8/page/1',1,'')
        addDir('Руски',site+'xfsearch/%D0%A0%D1%83%D1%81%D0%B8%D1%8F/page/1',1,'')
        addDir('Азиатски',site+'xfsearch/%D0%90%D0%B7%D0%B8%D0%B0%D1%82%D1%81%D0%BA%D0%B8/page/1',1,'')
        addDir('Индийски',site+'xfsearch/%D0%98%D0%BD%D0%B4%D0%B8%D0%B9%D1%81%D0%BA%D0%B8/page/1',1,'')
        addDir('Мюзикъл',site+'xfsearch/%D0%9C%D1%8E%D0%B7%D0%B8%D0%BA%D1%8A%D0%BB/page/1',1,'')
        addDir('Музикален',site+'xfsearch/%D0%9C%D1%83%D0%B7%D0%B8%D0%BA%D0%B0%D0%BB%D0%B5%D0%BD/page/1',1,'')
        addDir('Биографичен',site+'xfsearch/%D0%91%D0%B8%D0%BE%D0%B3%D1%80%D0%B0%D1%84%D0%B8%D1%87%D0%B5%D0%BD/page/1',1,'')
        addDir('Спортен',site+'xfsearch/%D0%A1%D0%BF%D0%BE%D1%80%D1%82%D0%B5%D0%BD/page/1',1,'')
        addDir('По действителен случай',site+'tags/%D0%BF%D0%BE%20%D0%B4%D0%B5%D0%B9%D1%81%D1%82%D0%B2%D0%B8%D1%82%D0%B5%D0%BB%D0%B5%D0%BD%20%D1%81%D0%BB%D1%83%D1%87%D0%B0%D0%B9/page/1',1,'')
        addDir('По книга',site+'tags/%D0%BF%D0%BE%20%D0%BA%D0%BD%D0%B8%D0%B3%D0%B0/page/1',1,'')
        addDir('3D',site+'3d/page/1',1,'')
        #addDir('','',1,'')




#Разлистване видеата на първата подадена страница
def INDEXPAGES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        #print 'request page url:' + url
        data=response.read()
        response.close()
        
        #Начало на обхождането
        br = 0 #Брояч на видеата в страницата
        
        #За muvibg
        if source =='0':
            match = re.compile('<span class="mod-custom3-poster"><a href="(.+?)"><img src="(.+?)" alt="(.+?)" /></a></span>').findall(data)
            for vlink, poster, title in match:
                addDir(title,vlink,3,poster)
                br = br + 1 #добавяме и това видео към общия брояч
        #Край на обхождането
        
        #За filmisub
        if source =='1':
            match = re.compile('<h2><a href="(.+?)">(.+?) {9}').findall(data)
            for vlink, title in match:
                addDir(title,vlink,3,logo)
                br = br + 1 #добавяме и това видео към общия брояч
        #Край на обхождането
        
        #За filmi7
        if source =='2':
            match = re.compile('<span class="pisssoka"><a href="(.+?)">(.+?)</a></span>').findall(data)
            for vlink, title in match:
                addDir(title,vlink,3,logo)
                br = br + 1 #добавяме и това видео към общия брояч
        #Край на обхождането
        
        #Ако резултатите са на повече от една страници
        #print 'Items counter: ' + str(br)
        if br > 4: #тогава имаме следваща страница и конструираме нейния адрес
            getpage=re.compile('(.+?)/page/(.+?)').findall(url)
            for baseurl,page in getpage:
                newpage = int(page)+1
                url = baseurl + '/page/' + str(newpage)
                #print 'URL OF THE NEXT PAGE IS:' + url
                thumbnail='DefaultFolder.png'
                addDir('следваща страница>>',url,1,thumbnail)






#Търсачка
def SEARCH(url):
        keyb = xbmc.Keyboard('', 'Търсачка')
        keyb.doModal()
        searchText = ''
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
            searchText=searchText.replace(' ','+')
            searchurl = url + searchText + '/page/1'
            searchurl = searchurl.encode('utf-8')
            #print 'SEARCHING:' + searchurl
            INDEXPAGES(searchurl)
        else:
            addDir('Върнете се назад в главното меню за да продължите','','',"DefaultFolderBack.png")






#Филми по години
def YEARS(url):
        b = int(datetime.now().year)
        n = 1950
        while b>=n:
            addDir(str(b),site+'xfsearch/'+str(b)+'/page/1',1,'')
            b = b - 1





#Подготвяне на видео
def LIST(name,url,iconimage):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        #print 'request page url:' + url
        data=response.read()
        response.close()
        
        #Повторно извличане на обложката  филма
        matchp = re.compile('"og:image" content="(.+?)"').findall(data)
        for poster in matchp:
            iconimage = poster
        
        br = 0 #Брояч на видеата в страницата
        match = re.compile('<iframe.*src="(.+?)".*frameborder="0"').findall(data)
        for vlink in match:
            if "youtu" in vlink: #Извличане на трейлъра на филма, ако има такъв
                trailer = vlink.replace('?rel=0&amp;wmode=transparent','')
                trailer = trailer.replace('embed/','watch?v=')
                addLink('Трейлър',trailer,4,iconimage)
            
            #поддръжка на playedto
            elif 'playedto' in vlink:
                req = urllib2.Request(vlink)
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data2=response.read()
                response.close()
                match2 = re.compile(',{file: "(.+?mp4)"}]').findall(data2)
                for plink in match2:
                    br = br + 1 #добавяме и това видео към общия брояч
                    if not (br%2) != 0:
                        title = 'резервен линк на ' + name
                    else:
                        title = name
                    addLink(title,plink,4,iconimage)
            
            #поддръжка на estream
            elif 'estream' in vlink:
                req = urllib2.Request(vlink)
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data2=response.read()
                response.close()
                match2 = re.compile('{file:"(.+?m3u8)"').findall(data2)
                for plink in match2:
                    br = br + 1 #добавяме и това видео към общия брояч
                    if not (br%2) != 0:
                        title = 'резервен линк на ' + name
                    else:
                        title = name
                    addLink(title,plink,4,iconimage)
            
            #За видеата в hdgo.cc
            elif 'hdgo' in vlink:
                req = urllib2.Request(vlink,'',headers)
                response = urllib2.urlopen(req)
                data2=response.read()
                response.close()
                match2 = re.compile('file:"(.+?mp4) ').findall(data2)
                for dlink in match2:
                    br = br + 1 #добавяме и това видео към общия брояч
                    if not (br%2) != 0:
                        title = 'резервен линк на ' + name
                    else:
                        title = name
                    addLink(title,dlink,4,iconimage)
                    #print 'dlink is ' + dlink
            
            
            #За видеата в rapidvideo
            elif 'rapidvideo' in vlink:
                req = urllib2.Request(vlink,'confirm.x=55&confirm.y=46&block=1')
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data2=response.read()
                response.close()
                match2 = re.compile('{"file":"(.+?)","label').findall(data2)
                br = br + 1 #добавяме и това видео към общия брояч
                if not (br%2) != 0:
                    title = 'резервен линк на ' + name
                else:
                    title = name
                addLink(title,match2[-1].decode('string_escape'),4,iconimage)
                #print 'rlink is ' + rlink
            
            
            
            #Поддръжка на субтитри във videomega
            elif 'videomega' in vlink:
                req = urllib2.Request(vlink)
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data=response.read()
                response.close()
                
                match = re.compile('<track kind="captions" src="(.+?)".*></track>').findall(data)
                for sub in match:
                    req = urllib2.Request(sub)
                    req.add_header('User-Agent', UA)
                    response = urllib2.urlopen(req)
                    data=response.read()
                    response.close()
                    with open(xbmc.translatePath('special://temp/filmi.Bulgarian.srt'), "w") as subfile:
                        subfile.write(data)
                        sub = 'true'
            
            
            else:
                br = br + 1 #добавяме и това видео към общия брояч
                if not (br%2) != 0:
                    title = 'резервен линк на ' + name
                else:
                    title = name
                #print 'muvibg: video hosting is ' + vlink
            
                #openload fix
                vlink = vlink.replace('oload','openload')
                addLink(title,vlink,4,iconimage)
                #print 'vlink is '+vlink
        
        #За сериалите в hdgo.cc
        match = re.compile("'(http://hdgo.+?)'+").findall(data)
        for vlink in match:
            br = br + 1 #добавяме и това видео към общия брояч
            title = '[' + str(br) + '] ' + name
            req = urllib2.Request(vlink,'',headers)
            response = urllib2.urlopen(req)
            data2=response.read()
            response.close()
            match2 = re.compile('file:"(.+?mp4) ').findall(data2)
            for dlink in match2:
                addLink(title,dlink,4,iconimage)
        
        #За сериалите в neodrive
        match = re.compile("'(http://neodrive.+?)'+").findall(data)
        for vlink in match:
            br = br + 1 #добавяме и това видео към общия брояч
            title = '[' + str(br) + '] ' + name
            addLink(title,vlink,4,iconimage)
        
        #За сериалите в openload
        match = re.compile("'(https://.+?load.+?)'+").findall(data)
        for vlink in match:
            vlink = vlink.replace('oload','openload')
            br = br + 1 #добавяме и това видео към общия брояч
            title = '[' + str(br) + '] ' + name
            addLink(title,vlink,4,iconimage)
        
        #За сериалите на други места
        match = re.compile('<br /><a href="(.+?)" target="_blank">').findall(data)
        brn = 0
        for vlink in match:
            br = br + 1 #добавяме и това видео към общия брояч
            if not (br%2) != 0:
                title = 'резервен линк на епизод [' + str(brn) + '] ' + name
            else:
                brn = brn + 1
                title = '[' + str(brn) + '] ' + name
            addLink(title,vlink,4,iconimage)




#Зареждане на видео
def PLAY(name,url,iconimage):
        #Playing resolved video link
        try:
            hmf = urlresolver.HostedMediaFile(url)
            if hmf:
                #Play via universal urlresolver
                pipeurl = urlresolver.resolve(url)
                #xbmc.executebuiltin("xbmc.PlayMedia("+pipeurl+")")
                item = xbmcgui.ListItem(path=pipeurl, iconImage=iconimage, thumbnailImage=iconimage)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            else:
                #Опитай директно отваряне, ако не се поддържа от urlresolver
                try:
                    item = xbmcgui.ListItem(path=url+'|User-Agent=stagefright', iconImage=iconimage, thumbnailImage=iconimage)
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
                #Отказваме се от това видео
                except:
                    xbmc.executebuiltin("Notification(Грешка,Не се поддържа от script.module.urlresolver,9000)")
        except:
                xbmc.executebuiltin("Notification(MUVIBG,Този хостинг не се поддържа. Използвайте резервен линк ако има такъв!,9000)")
        



#Парсване на RSS емисия за последно добавените заглавия
def FEEDPLAY(url):
        d = feedparser.parse(url)
        #print d
        e = len(d.entries)
        count = 0
        while (count < e):
            title=d.entries[count].title.encode('utf-8', 'ignore')
            matchl = re.compile("href': u'(.+?)'").findall(str(d.entries[count].links))
            matchc = re.compile('src="(.+?)"').findall(d.entries[count].summary.encode('utf-8', 'ignore'))
            try:
                addDir(title,matchl[-1],3,matchc[-1])
            except:
                pass
            count = count + 1





#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        name=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
    
elif mode==1:
        print ""+url
        INDEXPAGES(url)

elif mode==2:
        print ""+url
        SEARCH(url)

elif mode==3:
        print ""+url
        LIST(name,url,iconimage)

elif mode==4:
        print ""+url
        PLAY(name,url,iconimage)

elif mode==5:
        FEEDPLAY(url)

elif mode==6:
        YEARS(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
