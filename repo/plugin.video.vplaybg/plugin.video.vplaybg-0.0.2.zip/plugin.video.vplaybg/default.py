# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import time
import os
import urllib
import urllib2
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urlresolver
import json

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.vplaybg'
__Addon = xbmcaddon.Addon(__addon_id__)
searchicon = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/search.png")
srtsubs_path = xbmc.translatePath('special://temp/vplaybg.Bulgarian.srt')

MUA = 'Mozilla/5.0 (Linux; Android 5.0.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19' #За симулиране на заявка от мобилно устройство
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:50.0) Gecko/20100101 Firefox/50.0' #За симулиране на заявка от  компютърен браузър


#Меню с директории в приставката
def CATEGORIES():
        addDir('Търсене на видео','http://www.vplaybg.com/search.php?keywords=',2,searchicon)
        addDir('Игрални филми','http://www.vplaybg.com/category.php?cat=filmi&page=1&order=DESC',1,'DefaultVideo.png')
        addDir('Сериали','http://www.vplaybg.com/category.php?cat=SERIALI&page=1&order=DESC',1,'DefaultVideo.png')
        addDir('Анимации','http://www.vplaybg.com/category.php?cat=animation&page=1&order=DESC',1,'DefaultVideo.png')
        addDir('Музика','http://www.vplaybg.com/category.php?cat=allmusic&page=1&order=DESC',1,'DefaultAudio.png')
        #addDir('','',1,'')




#Разлистване видеата на първата подадена страница
def INDEXPAGES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()

        #Начало на обхождането
        br = 0 #Брояч на видеата в страницата - 24 за този сайт
        match = re.compile('vid=(.+?)" class="pm-title-link " title="(.+?)">').findall(data)
        for vid,title in match:
            title=title.replace('&quot;','')
            title=title.replace('&amp;','&')
            title=title.replace('[MP3 Download]','')
            #print title
            addLink(title,vid,3,'DefaultVideo.png')
            br = br + 1 #добавяме и това видео към общия брояч
            #Край на обхождането
        
        #Ако резултатите са на повече от една страници
        print 'Items counter: ' + str(br)
        if br == 24: #тогава имаме следваща страница и конструираме нейния адрес
            getpage=re.compile('(.+?)&page=(.+?)&order=DESC').findall(url)
            for baseurl,page in getpage:
                newpage = int(page)+1
                url = baseurl + '&page=' + str(newpage) + '&order=DESC'
                thumbnail='DefaultFolder.png'
                addDir('следваща страница>>',url,1,thumbnail)






#Търсачка
def SEARCH(url):
        keyb = xbmc.Keyboard('', 'Търсачка')
        keyb.doModal()
        searchText = ''
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
            searchText=searchText.replace(' ','+')
            searchurl = url + searchText + '&video-id=&page=1&order=DESC'
            searchurl = searchurl.encode('utf-8')
            INDEXPAGES(searchurl)
        else:
            addDir('Върнете се назад в главното меню за да продължите','','',"DefaultFolderBack.png")







#Зареждане на видео
def PLAY(name,url,iconimage):
        url = 'http://vplaybg.com/watch.php?vid=' + url #Конструираме адреса на страницата
        sub = 'false'
        
        req = urllib2.Request(url)
        req.add_header('User-Agent', UA)
        response = urllib2.urlopen(req)
        data=response.read()
        response.close()
        
        match = re.compile('<ifram.*src="(.+?)".*></iframe>').findall(data)
        for hlink in match:
            if 'youtube' in hlink:
                if not 'http' in hlink:
                    hlink = 'http:' + hlink
                    
            elif 'videomega' in hlink:
                req = urllib2.Request(hlink)
                req.add_header('User-Agent', UA)
                response = urllib2.urlopen(req)
                data=response.read()
                response.close()
                
                match = re.compile('<track kind="captions" src="(.+?)".*></track>').findall(data)
                for sub in match:
                    req = urllib2.Request(sub)
                    req.add_header('User-Agent', UA)
                    response = urllib2.urlopen(req)
                    data=response.read()
                    response.close()
                    with open(srtsubs_path, "w") as subfile:
                        subfile.write(data)
                        sub = 'true'
                        
            elif 'vbox7' in hlink:
                hlink = hlink.replace("//vbox7.com/emb/external.php?vid=","")
                jsonrsp = json.loads('{'+urllib2.urlopen('http://api.vbox7.com/v4/?action=r_video_play&video_md5=' + hlink + '&app_token=imperia_android_0.0.7_4yxmKd').read().split('{', 1)[-1])
                stream = jsonrsp['items'][0]['video_location']
                iconimage = jsonrsp['items'][0]['video_thumbnails']['big']
                
                try:
                    #Конвертиране на субтитрите в SRT формат
                    if not (jsonrsp['items'][0]['video_subtitles_path'] == ''):
                        response = urllib2.urlopen(jsonrsp['items'][0]['video_subtitles_path'])
                        subs = response.read().split("var sSubsJson = '", 1)[-1].split("';", 1)[0].decode('utf8').encode('raw_unicode_escape').decode('utf8', 'ignore').encode('utf8', 'ignore').replace("\\", "")
                        s = re.compile('{"s":"(.+?)","t":(\d+),"f":(\d+)}')
                        items = s.findall(subs)
                        row = 0
                        subs = ''
                        for i in items:
                            row = row + 1
                            subs += str(row) +'\n'
                            subs += time.strftime("%H:%M:%S,000", time.gmtime(int(i[2]))) + ' --> ' + time.strftime("%H:%M:%S,000", time.gmtime(int(i[1]))) + '\n'
                            subs += i[0].replace('+',' ').replace('<br>','\n')
                            subs += '\n\n'
                        sub = 'true'
                        with open(srtsubs_path, "w") as subfile:
                            subfile.write(subs)
                    else:
                        sub = 'false'
                except:
                    sub = 'false'
            
                
            hmf = urlresolver.HostedMediaFile(hlink)
            if hmf:
                stream = urlresolver.resolve(hlink)
        
        
        
        #Зареждане на видеото
        li = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=stream)
        li.setInfo('video', { 'title': name })
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path = stream))
        except:
            xbmc.executebuiltin("Notification('Грешка','Видеото липсва на сървъра!')")
                
        #Задаване на субтитри, ако има такива или изключването им
        if sub=='true':
            while not xbmc.Player().isPlaying():
                xbmc.sleep(1000) #wait until video is being played
                xbmc.Player().setSubtitles(srtsubs_path)
        else:
            xbmc.Player().showSubtitles(False)
        
        





#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty("IsPlayable" , "true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        name=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
    
elif mode==1:
        print ""+url
        INDEXPAGES(url)

elif mode==2:
        print ""+url
        SEARCH(url)

elif mode==3:
        print ""+url
        PLAY(name,url,iconimage)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
