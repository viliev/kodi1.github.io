class Mode:
	show_products = 'show_products'
	show_streams = 'show_streams'
	show_categories = 'show_categories'
	play = 'play'